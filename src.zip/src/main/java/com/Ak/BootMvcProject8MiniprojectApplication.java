package com.Ak;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootMvcProject8MiniprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootMvcProject8MiniprojectApplication.class, args);
	}

}
