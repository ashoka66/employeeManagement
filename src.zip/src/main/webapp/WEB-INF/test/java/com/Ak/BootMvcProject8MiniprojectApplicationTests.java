package com.Ak;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootMvcProject8MiniprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
